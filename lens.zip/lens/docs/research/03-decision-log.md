# Decision log

Chronological record of what was tried, what was found, and why the direction changed.
Numbers come from the result files in `docs/results/` (regenerable from `artifacts/`).

## Phase 1 — Lens (interactive screening on TREC-COVID)
1. **Data design.** Judged-only TREC-COVID pools; grades never used for candidates/features.
   Top-100 fused pools were 35–93% relevant (no headroom) → switched to full judged pools
   (~1,270 docs/topic) and a primary target of *highly relevant* (grade 2, ~19% on dev).
2. **First comparison (10 dev topics, budget 30).** Rocchio 22.1 found; TabPFN 21.7;
   logistic 19.9; static 18.5. TabPFN beat logistic on identical features (+1.8, CI
   +0.4…+3.3) but not Rocchio.
3. **Iterations (≈100 configs, GPUs):** feedback-similarity features, presumed negatives
   (hurt), multi-view embeddings (e5, BGE, MedCPT), per-topic PCA, past-session context
   (lifted logistic to Rocchio level), CORD-19 metadata (informative overall —
   pre-2020 papers 4.9% vs 27.9% highly relevant — but no ranking gain), stacking on the
   tuned Rocchio score. **No learned model beat tuned Rocchio** (best TabPFN −0.75 on 20
   dev topics). TabPFN's consistent edge: remaining-relevance estimates (recall error
   0.025 vs 0.042–0.051 logistic/Platt-Rocchio; tie with LightGBM 0.027).
4. **Held-out TREC-COVID test was never run**, deliberately: no configuration passed the
   dev go/no-go, and repeated dev tuning would have made a test win uninterpretable.

## Phase 2 — product framing
Options considered: Lens Review (screening copilot with a stop-when-done meter),
**Lens Feed** (personal paper feed with a confidence gate), Lens MCP (agent tool).
User chose **Lens Feed**.

## Phase 3 — Lens Feed
1. **Live source.** arXiv API rate-limited this network (HTTP 429); RSS empty on weekends;
   **OAI-PMH works** (official, CC0 metadata). One week of cs: 11,481 new papers in 38 s.
2. **Benchmark.** Scholar Inbox, 240 users (120 dev / 120 test, disjoint), prequential
   day-by-day replay, identical history for all learners.
3. **Dev iteration 1:** Rocchio best AUC (0.756); TabPFN on raw embeddings best-calibrated;
   hand-crafted tabular features hurt every learner.
4. **Bug found — age skew:** history rows' paper age measured *today*, not at rating time.
5. **Bug found — same-day leak:** history features could see same-session near-duplicate
   ratings with the same label; flexible models (TabPFN, LightGBM) exploited it, but it
   never exists at serving time. Fix: **leave-one-day-out** features (unit-tested).
6. **Dev iteration 3 (fixed):** TabPFN (embeddings + signals) ties Rocchio on AUC
   (−0.010, CI −0.034…+0.014) and beats all learned baselines on Brier/ECE.
7. **Pre-registration** (`docs/feed-test-preregistration.md`) written, then **one test run**.
8. **Test result:** H1 (Brier) and H2 (ECE) **supported** vs every probabilistic baseline;
   H3 (AUC within 0.02 of Rocchio) **not supported** (−0.005 to −0.010, CI misses margin).
9. **Product aligned with evidence:** TabPFN only after 10 👍 / 5 👎 (benchmarked regime),
   real dislikes only (no presumed negatives), embeddings + signals input; similarity
   ranking during cold start.

## Infrastructure notes
- Local: Python 3.11 via internal package index (tabpfn 9.0.0 includes v3.5 / v3.5-fast).
- Remote: Coder instance, 8× A10G; experiments later restricted to **GPUs 4–7** (enforced
  in `scripts/run_grid.sh`). Thread caps needed to avoid CPU oversubscription.
- TabPFN token passed per command via environment; the TabPFN library itself cached it at
  `~/.cache/tabpfn/auth_token` on the instance — delete it when rotating the key.
