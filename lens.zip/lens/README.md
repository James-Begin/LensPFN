# 🔭 Lens Feed — a paper feed that knows how sure it is

**In the week we measured (2026-09-25 → 10-02), arXiv announced 11,481 new computer-science
papers. You can read ten.**
Lens Feed ranks each day's new arXiv papers for *you*, learns from every 👍/👎 with
**TabPFN-3.5** (in-context, no training), and only interrupts you when it is genuinely
confident a paper is worth your time.

Built for the TabPFN-3.5 hackathon. Runs locally; your ratings never leave your machine.

## Result (held-out users, pre-registered)

We replayed **real explicit 👍/👎 ratings** from [Scholar Inbox](https://github.com/avg-dev/scholar_inbox_datasets)
(120 held-out users, disjoint from the 120 users used for every design decision; each day
every model ranks the papers that user actually rated, using only earlier ratings).
The test plan was frozen before running: [`docs/feed-test-preregistration.md`](docs/feed-test-preregistration.md).

| Model (same inputs unless noted) | Brier ↓ | Calibration error ↓ | Ranking AUC |
|---|---|---|---|
| **TabPFN-3.5-Fast** (Lens Feed) | **0.191** | **0.158** | 0.714 |
| **TabPFN-3.5** | **0.190** | **0.154** | 0.718 |
| Logistic regression on embeddings (Scholar Inbox's model family) | 0.208 | 0.179 | 0.696 |
| Logistic regression, same inputs as TabPFN | 0.208 | 0.185 | 0.708 |
| LightGBM, same inputs as TabPFN | 0.258 | 0.256 | 0.669 |
| Platt-calibrated Rocchio | 0.217 | 0.179 | 0.605 |
| Rocchio (tuned; scores, not probabilities) | — | — | **0.724** |

- **H1/H2 supported:** TabPFN's like-probabilities beat *every* probabilistic baseline on
  Brier score and calibration error (paired over users, all 95% CIs below zero; better
  Brier for 87/120 users vs. the best baseline).
- **H3 not supported:** ranking is about level with tuned Rocchio (−0.005 to −0.010 AUC),
  but the confidence interval misses our pre-set ±0.02 non-inferiority margin. We do not
  claim better ranking. Full numbers: [`docs/results/feedbench.md`](docs/results/feedbench.md).

**Why it matters:** a feed that notifies you needs probabilities you can trust — "80% match"
should mean ~80% of such papers are ones you like. That is exactly where TabPFN won.

Caveat: Scholar Inbox's dislikes are papers its own ranker showed, so this measures
re-ranking and probability quality among plausible papers, not discovery from all of arXiv.

## How it works

1. **Harvest** new papers from arXiv via OAI-PMH (CC0 metadata; ≤ 1 request / 3.5 s, cached).
2. **Embed** title + abstract with `intfloat/e5-small-v2` (cached on disk).
3. **Shortlist** by similarity to your likes/dislikes/interests (Rocchio).
4. **TabPFN-3.5 re-ranks the shortlist** from one row per paper: its embedding plus
   relational signals relative to *your* history — similarity to likes and dislikes,
   shared authors, category overlap, paper age. Your ratings are TabPFN's context: each
   click is a refit (a forward pass), not a training run.
5. **Confidence gate:** papers with match ≥ your threshold go to *Worth reading*.
6. **Explanations:** closest paper you liked, shared authors.

Cold start: until you have 10 👍 and 5 👎 (the regime we benchmarked), ranking is by
similarity and no match scores are shown.

Two leakage fixes were essential (and are in the product): history features are computed
**leave-one-day-out** (papers rated in the same session are near-duplicates with the same
label) and paper **age is measured at rating time**. Without them, flexible models
(TabPFN, LightGBM) learned spurious patterns that do not exist at serving time.

## Run it

Python ≥ 3.11 and [uv](https://docs.astral.sh/uv/):

```bash
uv sync --extra semantic --extra tabpfn --extra feed
uv run streamlit run src/lens/feed/app.py
```

Then: *Fetch new papers from arXiv* (sidebar) → seed a few liked papers by arXiv ID →
rate a handful of results. TabPFN weights download on first use; **you must accept the
TabPFN license** ([instructions](https://docs.priorlabs.ai/quickstart)) and set your own
`TABPFN_TOKEN` in the environment — never commit it. Apple Silicon (MPS), CUDA and CPU work;
a re-rank took ~1 s on an M-series Mac in our tests.

## Reproduce the benchmark

```bash
uv sync --extra semantic --extra tabpfn --extra bench
git clone --depth 1 https://github.com/avg-dev/scholar_inbox_datasets .cache/bench/scholar_inbox_datasets
uv run lens bench-prepare --ratings .cache/bench/scholar_inbox_datasets/data/rated_papers.csv \
  --output artifacts/feedbench --users 240 --device cuda          # downloads ~3 GB CC0 arXiv metadata
uv run lens bench-run --bench artifacts/feedbench --split test --device cuda \
  --learners embsig:tabpfnfast rocchio:g0.5 emb:logistic+C0.03 --output artifacts/fbtest/run
python scripts/feedbench_report.py artifacts/fbtest
python scripts/feedbench_hypotheses.py artifacts/fbtest
```

Use `--user-shard k/n` to parallelize (we used 8 A10G GPUs). Learner specs are
`<view>:<model>` — see `src/lens/feedbench.py`.

## Licenses and data

- **TabPFN-3.5 weights:** TABPFN-3.5 License v1.0 — non-commercial/evaluation. A commercial
  Lens Feed would need Prior Labs' commercial license or API.
- **arXiv metadata:** CC0 ([API terms](https://info.arxiv.org/help/api/tou.html)); Lens links to
  arXiv abstract pages and never hosts PDFs. Not endorsed by arXiv.
- **Scholar Inbox ratings:** CC BY-NC-ND 4.0 — used only for evaluation; not shipped or
  redistributed. Cite the Scholar Inbox paper ([arXiv:2504.08385](https://arxiv.org/abs/2504.08385)).

## Documentation

Full index: [`docs/README.md`](docs/README.md) — pre-registration, results, research notes, decision log.

## Research log (how we got here)

Lens started as interactive evidence screening on TREC-COVID (`lens prepare/evaluate`,
judged-only pools, BEIR archive). Across ~100 configurations on dev topics — feedback
features, presumed negatives, three embedding models (e5, BGE, MedCPT), past-session
context, CORD-19 metadata, stacking — **no learned model (TabPFN, logistic, LightGBM)
beat tuned Rocchio at finding relevant documents**, and we never ran that held-out test.
TabPFN's one consistent edge there was probability quality for estimating remaining
relevant documents, which motivated building Lens Feed around calibrated match scores.
That code remains in `src/lens/{data,features,learners,evaluate,meta,views,docmeta}.py`.
